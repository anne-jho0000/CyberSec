document.getElementById('loginForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const email = document.getElementById('email').value.trim().toLowerCase();
  const password = document.getElementById('password').value;
  const errorDiv = document.getElementById('loginError');

  let users = JSON.parse(localStorage.getItem('users') || '[]');
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    localStorage.setItem('loggedIn', 'true');
localStorage.setItem('currentUser', JSON.stringify(user)); // user is the logged-in user object
    window.location.href = "index.html";
  } else {
    errorDiv.textContent = "Invalid email or password!";
    errorDiv.style.display = "block";
  }
});