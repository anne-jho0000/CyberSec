document.getElementById('registerForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim().toLowerCase();
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirm-password').value;
  const errorDiv = document.getElementById('registerError');

  if (password !== confirmPassword) {
    errorDiv.textContent = "Passwords do not match!";
    errorDiv.style.display = "block";
    return;
  }

  let users = JSON.parse(localStorage.getItem('users') || '[]');
  if (users.find(u => u.email === email)) {
    errorDiv.textContent = "Email already registered!";
    errorDiv.style.display = "block";
    return;
  }

  users.push({ name, email, password });
  localStorage.setItem('users', JSON.stringify(users));
  errorDiv.style.color = "green";
  errorDiv.textContent = "Registration successful! Redirecting to login...";
  errorDiv.style.display = "block";
  setTimeout(() => window.location.href = "login.html", 1500);
});